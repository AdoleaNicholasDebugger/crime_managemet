
<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "don";
$dbname = "nacoss";
?>