<table width="80%" border="2" bgcolor="#000000" >
	
    <tr>
    <th colspan="8"><span class="style1"><font color="#FFFFFF"><center>search result<a href="../home/index.html"></label>
    </a>      <label></label></th>
    </tr>
    <tr>
	 <td bgcolor="#990066" align="center"><span class="style3">Crime no</span></td>
	 <td bgcolor="#FFFFFF"><span class="style8">Crime title</span></td>
    <td bgcolor="#990000"><span class="style3">Suspect name</span></td>
    <td bgcolor="#FFFFFF"><span class="style9">Department</span></td>
	 <td bgcolor="#990033"><span class="style3">rustication Date</span></td>
    
    </tr>
<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
<?php
include '../config/dbconfig.php'

?>
<?php

error_reporting(E_ALL ^ E_NOTICE);
 
$query=$_POST['query'];
$post=$_POST['post'];



//Connects to your Database
 
	mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');
	
	if($post=="Citizen")
	{
	$query=$_POST["query"];
	$query=mysql_real_escape_string($_GET['query']);

 
	$sql="SELECT * FROM citizens_register WHERE

First_name like '%".$query."%'";
	$result_set=mysql_query($sql);
	while($row=mysql_fetch_array($result_set))
       
	{
		?>
		 <tr>
		<td align="center" ><font color="#FFFFFF"><?php echo $row['First_name'] ?></td>
	
	
        <td><font color="#FFFFFF"><?php echo $row['Other_Names'] ?></td>
        <td><font color="#FFFFFF"><?php echo $row['State'] ?></td>
        <td><font color="#FFFFFF"><?php echo $row['LGA'] ?></td>
		<td><font color="#FFFFFF"><?php echo $row['Home_address'] ?></td>
       
        </tr>
        <?php
	}
}

	if($post=="Foreigner")
	{
	$query=$_POST["query"];
	$query=mysql_real_escape_string($_GET['query']);

 
	$sql="SELECT * FROM foreigners_register WHERE

Firstname like '%".$query."%'";
	$result_set=mysql_query($sql);
	while($row=mysql_fetch_array($result_set))
	
	
	{
		?>
        <tr>
		<td align="center" ><font color="#FFFFFF"><?php echo $row['Firstname'] ?></td>
        <td><font color="#FFFFFF"><?php echo $row['othernames'] ?></td>
        <td><font color="#FFFFFF"><?php echo $row['countryorigin'] ?></td>
        <td><font color="#FFFFFF"><?php echo $row['stateResident'] ?></td>
		<td><font color="#FFFFFF"><?php echo $row['LGAresident'] ?></td>
		<td><font color="#FFFFFF"><?php echo $row['residentialadress'] ?></td>
		<td><font color="#FFFFFF"><?php echo $row['permitNo'] ?></td>
       
        </tr>
        <?php
	}
}


if($result){

?>
		<script>
		alert('Search Found');
        window.location.href='home/admindashboard.php';
        </script>
		<?php
	}
	else
	{
		?>
		<script>
		alert('error while Searching Data');
        window.location.href='home/admindashboard.php';
        </script>
		<?php
	}
	

 ?>
 <table width="80%" border="2" bgcolor="#000000" >
	
    <tr>
    <th colspan="8"><span class="style1"><font color="#FFFFFF"><center>search result<a href="../home/index.html"></label>
    </a>      <label></label></th>
    </tr>
    <tr>
	 <td bgcolor="#990066" align="center"><span class="style3">First_name</span></td>
	 <td bgcolor="#FFFFFF"><span class="style8">Other_Names</span></td>
    <td bgcolor="#990000"><span class="style3">State</span></td>
    <td bgcolor="#FFFFFF"><span class="style9">LGA</span></td>
	 <td bgcolor="#990033"><span class="style3">Home_address</span></td>
    
    </tr>
	
<?php
	error_reporting(E_ALL ^ E_NOTICE);
	$query=$_POST["query"];

$query=mysql_real_escape_string($_GET['query']);

 
	$sql="SELECT * FROM rusticate WHERE

Suspect_name like '%".$query."%'";
	$result_set=mysql_query($sql);
	while($row=mysql_fetch_array($result_set))
	
	
	{
		?>
        <tr>
		<td align="center" ><font color="#FFFFFF"><?php echo $row['Crime_no'] ?></td>
        <td><font color="#FFFFFF"><?php echo $row['Crime_title'] ?></td>
        <td><font color="#FFFFFF"><?php echo $row['Suspect_name'] ?></td>
        <td><font color="#FFFFFF"><?php echo $row['Dept'] ?></td>
		<td><font color="#FFFFFF"><?php echo $row['date_of_rustication'] ?></td>
       
        </tr>
        <?php
	}
	?>
</table>