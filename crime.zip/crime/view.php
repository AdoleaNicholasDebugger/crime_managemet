<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">

<?php
include 'config/dbconfig.php'
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title></title>
<link rel="stylesheet" href="style.css" type="text/css" />
<script language='JavaScript' type='text/JavaScript'>
<!--
function validate() {
	if(document.form1.query.value=='')
		{
		alert('input your Reg_No');
		return false;
		}
          else	{
		return true;
			}
}
//-->



</script>
<style type="text/css">
<!--
.style1 {
	color: #0000FF;
	font-weight: bold;
}
.btn {
	-webkit-box-shadow:rgba(0,0,0,0.2) 0 1px 0 0;
	-moz-box-shadow:rgba(0,0,0,0.2) 0 1px 0 0;
	box-shadow:rgba(0,0,0,0.2) 0 1px 0 0;
	border-bottom-color:#333;
	border:1px solid #61c4ea;
	background-color:#7cceee;
	border-radius:5px;
	-moz-border-radius:5px;
	-webkit-border-radius:5px;
	color:#333;
	font-family:'Verdana',Arial,sans-serif;
	font-size:14px;
	text-shadow:#b2e2f5 0 1px 0;
	padding:5px
}
.style4 {color: #990000; font-weight: bold; }
.style5 {color: #FF0000}
.style6 {color: #0000FF}
-->
</style>
</head>
<body>

<div>
<div id="body">
<table align="center">
<tr><td> <img src="images/logo.jpg" width="980" height="158" align align="center" /></td></tr>
</table>
	<table width="80%" border="1" bgcolor="#FFFFFF" align="center">
	
    <tr>
    <th colspan="5"><span class="style1"></span><span class="style6">
	
	Most wanted</span>
    </tr>
    <tr>
	<td><span class="style4">crimeid</span></td>
	
	 <td><span class="style4">First Name</span></td>
    <td><span class="style4">Last Name</span></td>
    <td><span class="style4">charges</span></td>
    <td><span class="style4">Photo</span></td>
    </tr>
    <?php
	
	error_reporting(E_ALL ^ E_NOTICE);
	$query=$_POST["query"];
	

$query=($_GET['query']);

 $sql = mysqli_query($db,"SELECT * from wanted") or die(mysqli_error());
	
	
	
	while($row=mysqli_fetch_array($sql))
	
	
	{
	$crimeid = $row["crimeid"]; 
	$Firstname = $row["Firstname"]; 
	$othernames = $row["othernames"]; 
	$charges = $row["charges"]; 
		?>
        <tr>
		<td><?php echo $row['crimeid'] ?></td>
        <td><?php echo $row['Firstname'] ?></td>
        <td><?php echo $row['othernames'] ?></td>
		 <td><?php echo $row['charges'] ?></td>
        <td><a href="images\<?php echo $row['phot'] ?>" target="_blank">view picture </a></td>
        </tr>
		
		
        <?php
	}
	?>
    </table>
   
</div>

<form name="form1" enctype="multipart/form-data" action="yyy.php" method="POST" >
</form>
</body>
</html>






