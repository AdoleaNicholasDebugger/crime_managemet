<?php
include '../config/dbconfig.php';
?>
<?php
//Connects to your Database
mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');
	?>
<!doctype html>
<html>
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Crime</title>
<link rel="stylesheet" href="styles.css" type="text/css" />
<!--
spigot, a free CSS web template by ZyPOP (zypopwebtemplates.com/)

Download: http://zypopwebtemplates.com/

License: Creative Commons Attribution
//-->
<style type="text/css">
<!--
.style1 {color: #990033}
.style2 {color: #990066}
.style3 {
	color: #FFFFFF;
	font-weight: bold;
	font-size: 18px;
}
.style8 {font-weight: bold; font-size: 18px; color: #990000; }
.style9 {font-weight: bold; font-size: 18px; color: #990033; }
-->
</style>
</head>
<body>
<div id="container">
  <header>
    	<h1><a href="/"><img src="logo.jpg" align="middle"></span></a></h1>
        
  </header>
    
    <div id="body">
		
        <section id="content">

	    <article>
	    
            
            <div class="clear"></div>
  </div>
     
    </footer>
	
</div>

<table width="1129" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutDefaultTable-->
  <tr>
    <td width="455" height="209">&nbsp;</td>
    <td width="366" valign="top"> <script src="http://s.codepen.io/assets/libs/modernizr.js" type="text/javascript"></script>


    
      <link rel="stylesheet" href="css/reset.css">

      <link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css'>

        <link rel="stylesheet" href="css/style.css">

    
    
    
      </head>

      <body>

  
     <form id="form1" name="form1" action="track_Crimeprocessor.php" method="post" enctype="multipart/form-data" onSubmit='return validate();' class="login">     
        <fieldset>
            
       <p class="style2"> ......Track Criminals</p>
      
    <div class="input">
      <input type="search" name="query" placeholder="search by name" required />
      <span><i class="fa fa-envelope-o"></i></span>      </div>
      <p class="left">
		  <label for="UserName">Select Status </label>
		  <select name="post" >
            <option>select</option>
            <option>Citizen</option>
            <option>Foreigner</option>
                     </select>
		 </p>
   
      
      
        <input  type="submit" value="Search" >
  </fieldset>
    
  <div class="feedback">
      </div>
      </form>
      <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

        <script src="js/index.js"></script>

    
    
    &nbsp;</td>
  <td width="499">&nbsp;</td>
  </tr>
</table>


</body>
</html>
