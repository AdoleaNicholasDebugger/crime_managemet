<html>
<head><title>Omolola</title>
</head>
</html>


<style type="text/css">
<!--
.style1 {color: #000099}
.style4 {color: #00FF00}
.style5 {color: #0000FF}
.style6 {color: #009999}
.style17 {color: #660033}
-->
</style>
<div align="center">
  <div align="center">
    <table width="915" border="0" cellpadding="0" cellspacing="0" bgcolor="#990033">
      <!--DWLayoutTable-->
      <tr>
        <td height="79" colspan="4" valign="top">&nbsp;<img src="logo.jpg" width="730" height="98" /></td>
      </tr>
      <tr>
        <td width="21" height="69">&nbsp;</td>
        <td width="194">&nbsp;</td>
        <td width="687">&nbsp;</td>
        <td width="13">&nbsp;</td>
      </tr>
      <tr>
        <td height="27">&nbsp;</td>
        <td valign="top" bgcolor="#FFFFFF"><span class="style5">Congratulations!</span></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      
      <tr>
        <td height="397">&nbsp;</td>
        <td colspan="2" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
          <!--DWLayoutTable-->
          <tr>
            <td width="4" height="28">&nbsp;</td>
              <td width="128">&nbsp;</td>
              <td width="3">&nbsp;</td>
              <td width="14">&nbsp;</td>
              <td width="283">&nbsp;</td>
              <td width="10">&nbsp;</td>
              <td width="24">&nbsp;</td>
              <td width="36">&nbsp;</td>
              <td width="379">&nbsp;</td>
            </tr>
          <tr>
            <td height="15"></td>
              <td rowspan="3" valign="top"><img src="correct.png" width="128" height="128" /></td>
          <td></td>
              <td></td>
              <td>
              <td>              
              <td>              
              <td>              
              <td></td>
            </tr>
          <tr>
            <td height="20"></td>
            <td></td>
            <td colspan="4" valign="top">                                                                                                                                                      
                
                
                
              
              
                <p><span class="style6"><strong><span class="style5">  System installed succesfully <i>!</i></span></strong></span></p>
              <td>          
            <td></td>
          </tr>
          <tr>
            <td height="93"></td>
            <td></td>
            <td>&nbsp;</td>
            <td>          
            <td>          
            <td>          
            <td>          
            <td></td>
          </tr>
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          <tr>
            <td height="52">&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
          <tr>
            <td height="19">&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td valign="top"><span class="style4"><a href="../index.html"><span class="style17"><strong> click to visit </strong> Home page </span></a></span>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
          <tr>
            <td height="38">&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td colspan="2" valign="top"><br />
                <span class="style1"> Stage 3/3</span></td>
          <td>&nbsp;</td>
            </tr>
          <tr>
            <td height="132">&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
        </table></td>
        <td>&nbsp;</td>
      </tr>
      <tr>
        <td height="41">&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      </table>
</div>
  </div>
