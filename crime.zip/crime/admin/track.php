<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
<?php
session_start();

error_reporting(E_ALL ^ E_NOTICE);


?>



<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<title>Crime search </title>
<link rel="stylesheet" href="style.css" type="text/css" />
<script language='JavaScript' type='text/JavaScript'>
<!--
function validate() {
	if(document.form1.query.value=='')
		{
		alert('input the Suspect Name');
		return false;
		}
          else	{
		return true;
			}
}
//-->



</script>
<style type="text/css">
<!--
.style1 {
	color: #0000FF;
	font-weight: bold;
}
.style6 {color: #0000FF}
.style9 {color: #333333}
-->
</style>
</head>
<body>

<table width="748" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutDefaultTable-->
  <tr>
    <td width="1" height="33"></td>
    <td width="295"></td>
    <td width="400"></td>
    <td width="268"></td>
  </tr>
  <tr>
    <td height="150"></td>
    <td colspan="3" valign="top"><img src="logo.jpg"></td>
  </tr>
  <tr>
    <td height="253"></td>
    <td>&nbsp;</td>
    <td valign="top"><div id="header">
      <label></label>
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    </div>
      <div>
        <p>*********************************************</p>
        </div>      <form method="get" action="trckprocess.php" name="form1" onSubmit='return validate();'>
        <label><font color="BLUE"><B>Type Suspect's Name*</font> </label>
        <input type="text" name="query" />
        <input type="submit" name="submit" value="Track" />
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      </form></td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
