<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
<title>NACOSS e-Voting</title>
<?php
include '../config/dbconfig.php';
?>
<?php

//error_reporting(E_ALL ^ E_NOTICE);
 //This is the directory where images will be saved
 $target = "images/";
 $target = $target . basename( $_FILES['photo']['name']);

 //This gets all the other information from the form

$CrimeNo=$_POST['CrimeNo'];
 $Stationcode=$_POST['Stationcode'];
 $Division=$_POST['Division'];
 $CaseIPO=$_POST['CaseIPO'];
 $SuspectName=$_POST['SuspectName'];
  $SuspectAddress=$_POST['SuspectAddress']; 
 $Complenant=$_POST['Complenant'];
 $dat=$_POST['dat'];
 $Report=$_POST['Report'];
 $CrimeType=$_POST['CrimeType'];
 $charges=$_POST['charges'];
 $pic=($_FILES['photo']['name']);
 
 
 
 if($CrimeType=="Murder") {


  
  
 //$e_id ="inec/ 396" ;
//	$attempt  = "1";
//$pres_result = mysql_query("SELECT pres_attempts FROM attempts where election_id ='$e_id'");
 //while($pres_row = mysql_fetch_row($pres_result)){
 //$pres_attempt =  $pres_row ['pres_attempts'];
  // if ($pres_attempt >= 1){
//header("location:error.php");
 
$names = 0;
$result =mysqli_query($db,"SELECT count FROM graph where category ='Murder'");
 while($row = mysqli_fetch_row($result)){
   $names =  $row [0];
   $names =  $names + 1;
   
   mysqli_query($db,"UPDATE graph SET count=$names WHERE category ='Murder' ");
   mysqli_query($db,"UPDATE attempts SET pres_attempts = '$attempt' WHERE election_id ='$e_id' ");
 

   
} 

 
  }
 
//************************************************************************************************************************
if($CrimeType=="Militancy") {


 //$e_id ="inec/ 396" ;
//	$attempt  = "1";
//$pres_result = mysql_query("SELECT pres_attempts FROM attempts where election_id ='$e_id'");
 //while($pres_row = mysql_fetch_row($pres_result)){
 //$pres_attempt =  $pres_row ['pres_attempts'];
  // if ($pres_attempt >= 1){
//header("location:error.php");
 
$names = 0;
$result = mysqli_query($db,"SELECT count FROM graph where category ='Militancy'");
 while($row = mysqli_fetch_row($result)){
   $names =  $row [0];
   $names =  $names + 1;
   
   mysqli_query($db,"UPDATE graph SET count=$names WHERE category ='Militancy' ");
   mysqli_query($db,"UPDATE attempts SET pres_attempts = '$attempt' WHERE election_id ='$e_id' ");
 

   
} 

 
  }
 
//*8888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888888
if($CrimeType=="Robbery") {



 //$e_id ="inec/ 396" ;
//	$attempt  = "1";
//$pres_result = mysql_query("SELECT pres_attempts FROM attempts where election_id ='$e_id'");
 //while($pres_row = mysql_fetch_row($pres_result)){
 //$pres_attempt =  $pres_row ['pres_attempts'];
  // if ($pres_attempt >= 1){
//header("location:error.php");
 
$names = 0;
$result = mysqli_query($db,"SELECT count FROM graph where category ='Robbery'");
 while($row = mysqli_fetch_row($result)){
   $names =  $row [0];
   $names =  $names + 1;
   
   mysqli_query($db,"UPDATE graph SET count=$names WHERE category ='Robbery' ");
   mysqli_query($db,"UPDATE attempts SET pres_attempts = '$attempt' WHERE election_id ='$e_id' ");
 

   
} 

 
  }
 
//*****************************************************************************************************************************
if($CrimeType=="Rape") {


 //$e_id ="inec/ 396" ;
//	$attempt  = "1";
//$pres_result = mysql_query("SELECT pres_attempts FROM attempts where election_id ='$e_id'");
 //while($pres_row = mysql_fetch_row($pres_result)){
 //$pres_attempt =  $pres_row ['pres_attempts'];
  // if ($pres_attempt >= 1){
//header("location:error.php");
 
$names = 0;
$result = mysqli_query($db,"SELECT count FROM graph where category ='Rape'");
 while($row = mysqli_fetch_row($result)){
   $names =  $row [0];
   $names =  $names + 1;
   
   mysqli_query($db,"UPDATE graph SET count=$names WHERE category ='Rape' ");
   mysqli_query($db,"UPDATE attempts SET pres_attempts = '$attempt' WHERE election_id ='$e_id' ");
 

   
} 

 
  }
 
//_____________________________________________________________________________________________________________________
 //*****************************************************************************************************************************
if($CrimeType=="Terrorism") {


 //$e_id ="inec/ 396" ;
//	$attempt  = "1";
//$pres_result = mysql_query("SELECT pres_attempts FROM attempts where election_id ='$e_id'");
 //while($pres_row = mysql_fetch_row($pres_result)){
 //$pres_attempt =  $pres_row ['pres_attempts'];
  // if ($pres_attempt >= 1){
//header("location:error.php");
 
$names = 0;
$result =mysqli_query($db,"SELECT count FROM graph where category ='Terrorism'");
 while($row = mysqli_fetch_row($result)){
   $names =  $row [0];
   $names =  $names + 1;
   
   mysqli_query($db,"UPDATE graph SET count=$names WHERE category ='Terrorism' ");
   mysqli_query($db,"UPDATE attempts SET pres_attempts = '$attempt' WHERE election_id ='$e_id' ");
 

   
} 

 
  }
 
//_____________________________________________________________________________________________________________________
 


if($_FILES['photo']['size']>500000)	
{
?>
		<script>
		alert('Image file too large, must be less than 500kb');
        window.location.href='index.html';
        </script>
		<?php
}
elseif($_FILES['photo']['size']<=0)
{
?>
		<script>
		alert('Image file not loaded');
        window.location.href='index.html';
        </script>
		<?php
}
	else
	{
	$query="select * from station_report ";
	$pin=1;
	
	//........................................
	$result=mysqli_query($db,$query);
	
	while ($row = mysqli_fetch_array($result)) {
$pin=$pin+1; 
}

$query="insert into station_report
values('$pin','$CrimeNo','$Stationcode','$Division','$CaseIPO','$SuspectName','$SuspectAddress','$Complenant','$dat','$Report','$CrimeType','$charges','$pic')";


$result=mysqli_query($db,$query);
//Writes the photo to the server
if($result){
 if(move_uploaded_file($_FILES['photo']['tmp_name'], $target))

?>
		<script>
		alert('successfully uploaded');
        window.location.href='../admin/admindashboard.php';
        </script>
		<?php
	}
	else
	{
		printf("Connect failed: %s\n", $mysqli->connect_error);
	}
	}

 ?>