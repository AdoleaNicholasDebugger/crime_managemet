<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
<?php
session_start();

error_reporting(E_ALL ^ E_NOTICE);


?>



<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<title>Crime search </title>
<link rel="stylesheet" href="style.css" type="text/css" />
<script language='JavaScript' type='text/JavaScript'>
<!--
function validate() {
	if(document.form1.query.value=='')
		{
		alert('input the Suspect Name');
		return false;
		}
          else	{
		return true;
			}
}
//-->



</script>
</head>
<body>

<table width="1105" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutDefaultTable-->
  <tr>
    <td width="142" height="33">&nbsp;</td>
    <td width="127">&nbsp;</td>
    <td width="84">&nbsp;</td>
    <td width="124">&nbsp;</td>
    <td width="400">&nbsp;</td>
    <td width="228">&nbsp;</td>
  </tr>
  <tr>
    <td height="150">&nbsp;</td>
    <td colspan="5" valign="top"><img src="logo.jpg"></td>
  </tr>
  
  
  <tr>
    <td height="29"></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td rowspan="3" valign="top"><div id="header">
      <label></label>
    </div>
      <div>
        <p>*********************************************</p>
        </div>      <form method="get" action="convictproces.php" name="form1" onSubmit='return validate();'>
        <label><font color="BLUE"><B>Search Name*</font> </label>
        <input type="text" name="query" />
        <input type="submit" name="submit" value="Track" />
      </form></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="23"></td>
    <td>&nbsp;</td>
    <td valign="top"><a href="../index.html"><strong>HOME</strong></a></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td height="201"></td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
