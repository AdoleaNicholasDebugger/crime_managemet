<link rel="icon" type="image/png" sizes="16x16" href="../favicon-16x16.png">

<?php
session_start();

error_reporting(E_ALL ^ E_NOTICE);


?>

<?php
if(!isset($_SESSION['password']))
{
header("Location:Admin_Login.php"); 
die();
}
?>

<!DOCTYPE html>
<html lang="en">
<style type="text/css">
<!--
.style16 {font-size: 18px}
-->
</style>
<head>
		<title></title>
		<meta charset="utf-8">
		<link rel="stylesheet" href="css/reset.css" type="text/css" media="all">
		<link rel="stylesheet" href="css/layout.css" type="text/css" media="all">
		<link rel="stylesheet" href="css/style.css" type="text/css" media="all">
		<script type="text/javascript" src="js/jquery-1.6.js" ></script>
		<script type="text/javascript" src="js/cufon-yui.js"></script>
		<script type="text/javascript" src="js/cufon-replace.js"></script>  
		<script type="text/javascript" src="js/Vegur_300.font.js"></script>
		<script type="text/javascript" src="js/PT_Sans_700.font.js"></script>
		<script type="text/javascript" src="js/PT_Sans_400.font.js"></script>
		<script type="text/javascript" src="js/atooltip.jquery.js"></script>
		<!--[if lt IE 9]>
		<script type="text/javascript" src="js/html5.js"></script>
		<link rel="stylesheet" href="css/ie.css" type="text/css" media="all">
		<![endif]-->
		<!--[if lt IE 7]>
			<div style=' clear: both; text-align:center; position: relative;'>
				<a href="http://windows.microsoft.com/en-US/internet-explorer/products/ie/home?ocid=ie6_countdown_bannercode"><img src="http://storage.ie6countdown.com/assets/100/images/banners/warning_bar_0000_us.jpg" border="0" height="42" width="820" alt="You are using an outdated browser. For a faster, safer browsing experience, upgrade for free today." /></a>
			</div>
		<![endif]-->
	    <style type="text/css">
<!--
.style1 {
	color: #330000;
	font-weight: bold;
	font-size: 36px;
}
.style13 {
	color: #990000;
	font-weight: bold;
}
.style15 {color: #FFFFFF; font-weight: bold; font-size: 24px; }
.style18 {
	color: #990033;
	font-size: 16px;
}
.style21 {color: #FFFFFF}
.style23 {font-size: 24px; color: #FFFFFF;}
.style25 {color: #FFFFFF; font-weight: bold; }
.style27 {color: #FFFFFF; font-weight: bold; font-size: 16px; }
-->
        </style>
</head>
	<body id="page5">
		<div class="main">
<!--header -->
		  <header>
				<div class="wrapper">
				 
				  <form id="search" method="post">
				   <img src="logo.jpg" align="middle">
						<fieldset>
							
						</fieldset>
				  </form>
			</div>
		  </header>
<!--header end-->
<!--content -->
			<article id="content"></article>
		</div>
	    <script type="text/javascript"> Cufon.now(); </script>
	    <table width="1279" border="0" cellpadding="0" cellspacing="0">
	      <!--DWLayoutTable-->
	      
	      <tr>
	        <td width="272" height="3"></td>
            <td width="46"></td>
            <td width="355"></td>
            <td width="27"></td>
            <td width="74"></td>
            <td width="96"></td>
            <td width="53"></td>
            <td width="4"></td>
            <td width="352"></td>
	      </tr>
	      <tr>
	        <td height="18"></td>
	        <td></td>
	        <td rowspan="2" valign="top" bgcolor="#FFFFFF"><div align="center"><span class="style1"><marquee>Administrators <a href="logout.php"></marquee></a></span></div></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
	      </tr>
	      <tr>
	        <td height="43"></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td valign="top" bgcolor="#FFFFFF"><p><a href="login.html" class="style13">Logout</a></p></td>
          <td></td>
	        <td></td>
            <td></td>
	      </tr>
	      
	      
	      
	      <tr>
	        <td height="2"></td>
	        <td></td>
	        <td></td>
	        <td></td>
            <td colspan="3" rowspan="10" valign="top" align="center"><img src="Crime.jpg" width="223" height="231"></td>
            <td></td>
            <td rowspan="10" valign="top" bgcolor="#CCCCCC"><p align="center" class="style23">Crime Detection and Monitoring</p>
             <p class="style18"><span class="style21">--</span><strong><a href="track.php">Search Citizens</a></strong></p>              
            <p class="style18"><span class="style21">---</span>  <strong><a href="track2.php">Search Foreigners</a></strong> </p></td>
	      </tr>
	      <tr>
	        <td height="29"></td>
	        <td colspan="3" valign="top" bgcolor="#CCCCCC"><a href="../forms/assignpass.php" class="style15 style16">#Create Account </a></td>
	        <td></td>
          </tr>
	      <tr>
	        <td height="16"></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
          </tr>
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      <tr>
	        <td height="29"></td>
	        <td colspan="3" valign="top" bgcolor="#CCCCCC"><span class="style15"><a href="../forms/citizen.html">#Citizens Registration </a></span></td>
	        <td></td>
          </tr>
	      <tr>
	        <td height="18"></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
          </tr>
	      
	      <tr>
	        <td height="35"></td>
	        <td colspan="3" valign="top" bgcolor="#CCCCCC"><span class="style15"><a href="../forms/foreign.html">#Foreigners Registration</a></span></td>
	        <td></td>
          </tr>
	      <tr>
	        <td height="24"></td>
	        <td>&nbsp;</td>
	        <td></td>
	        <td></td>
	        <td></td>
          </tr>
	      
	      
	      
	      
	      <tr>
	        <td height="33"></td>
	        <td colspan="3" valign="top" bgcolor="#CCCCCC"><span class="style15"><a href="../forms/Wanted.html">#Most Wanted</a></span></td>
	        <td></td>
          </tr>
	      <tr>
	        <td height="17"></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
          </tr>
	      <tr>
	        <td height="48"></td>
	        <td></td>
          </tr>
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      <tr>
	        <td height="1"></td>
	        <td></td>
	        <td></td>
	        <td></td>
	        <td></td>
            <td></td>
	      </tr>
	      <tr>
	        <td height="76"></td>
	        <td>&nbsp;</td>
	        <td>&nbsp;</td>
	        <td>&nbsp;</td>
	        <td>&nbsp;</td>
	        <td>&nbsp;</td>
	        <td>&nbsp;</td>
	        <td></td>
            <td></td>
	      </tr>
    </table>
	
</body>
</html>
