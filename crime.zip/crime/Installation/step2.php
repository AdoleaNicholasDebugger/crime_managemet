<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>vehicle</title>

<style type="text/css">
<!--
.roundtable {
border: 1px solid #cbcbcb;
color:#666;
vertical-align:top;
margin-right:15px;
-moz-border-radius:7px; -webkit-border-radius:7px; -khtml-border-radius:7px; border-radius:7px; behavior: url(border-radius.htc);
}
-->
</style>

<style type="text/css">
.pp {
border-bottom-style: dashed ; 
border-bottom-color: yellow; 
border-bottom-width: 5px; 
 border-top-style: double; 
border-top-color: purple; 
border-top-width: thick; 
 border-left-style: groove; 
border-left-color: green; 
border-left-width: 15px; 
border-bottom-style: ridge; 
border-bottom-color: yellow; 
border-bottom-width: 25px; 
}

</style>

<style type="text/css">
<!--
body {
	background-color: #CCCCCC;
}
.style9 {color: #990033}
.style2 {	color: #660000;
	font-weight: bold;
}
.style14 {color: #FFFFFF}
-->
</style>
</head>

<body>
<div align="center">
  <table width="793" border="0" cellpadding="0" cellspacing="0">
    <!--DWLayoutTable-->
    
    <tr>
      <td width="209" height="79">&nbsp;</td>
      <td width="400" valign="top"><img src="logo.jpg" width="730" height="98" />&nbsp;</td>
      <td width="184">&nbsp;</td>
    </tr>
  </table>
</div>
<div align="center">
  <div align="center">
    
</div>
<div align="center"></div>
<div align="center"></div>
<div align="center">
  <table width="800" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" class="roundtable">
    <!--DWLayoutTable-->
    <tr>
      <td width="1" height="15"></td>
      <td width="800"></td>
    </tr>
    <tr>
      <td height="584"></td>
      <td valign="top"><table width="800" border="0" cellpadding="0" cellspacing="0">
        <!--DWLayoutTable-->
        <tr>
          <td width="250" height="19" valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
      <td width="267" valign="top"><span class="style2">Installation module </span></td>
      <td width="66" valign="top"><span class="style1 style9">Stage 2/3</span></td>
      <td width="217">&nbsp;</td>
    </tr>
        <tr>
          <td height="37">&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
        <tr>
          <td height="528" colspan="4" valign="top"><table width="800" border="0" cellpadding="0" cellspacing="0" bgcolor="#990033">
            <!--DWLayoutTable-->
            <tr>
              <td width="785" height="528" valign="top" bgcolor="#990033">
                
                <div align="center">
                  <?php

error_reporting(E_ALL ^ E_NOTICE);

	$db = @mysql_connect($_POST['db_host'] . ':' . $_POST['db_port'], $_POST['db_login'], $_POST['db_password']);
	if (!$db) {
		$errors[] = 'Unable to connect to database server.';
	} else {
		// check mysql version number
		$sql = "SELECT VERSION() AS version";
		$result = mysql_query($sql, $db);
		$row = mysql_fetch_assoc($result);
		if (version_compare($row['version'], '4.1.10', '>=') === FALSE) {
			$errors[] = 'MySQL version '.$row['version'].' was detected. AContent requires version 4.1.10 or later.';
		}

		if (!isset($errors)){
			if (!mysql_select_db($_POST['db_name'], $db)) {
				$sql = "CREATE DATABASE $_POST[db_name] CHARACTER SET utf8 COLLATE utf8_general_ci";
				$result = mysql_query($sql, $db);
				if (!$result) {
					$errors[] = 'Unable to select or create database <b>'.$_POST['db_name'].'</b>.';
				} else {
					echo '<font color="green">Database <b>'.$_POST['db_name'].'</b> created successfully.';
					mysql_select_db($_POST['db_name'], $db);
                                        
                                      

 
 // Create a MySQL table in the selected database
mysql_query("CREATE TABLE citizens_register(
`cid` int(5) default NULL,
`First_name` varchar(19) ,
`Other_Names` varchar(19),
`Gender` varchar(19),
`Complexion` varchar(29),
`Facial_Mark` varchar(29),
`Height` varchar(29),
`State` varchar(29) ,
`LGA` varchar(29),
`Home_address` varchar(29),
`PlaceOfBirth` varchar(29) ,
`Photo` BLOB(19),
`dat` varchar(19),
`MotherName` varchar(19),
`FatherName` varchar(29),
`parentsResidentialAddress` varchar(75),
PRIMARY KEY  (cid)
)")
 or die(mysql_error());
 
 // Create a MySQL table in the selected database
mysql_query("CREATE TABLE station_report(
`id` int(5) default NULL,
`case_id` varchar(19),
`stationcode` varchar(19) ,
`divisioncode` varchar(19),
`caseIPO` varchar(19),
`suspectName` varchar(29),
`SuspectAddress` varchar(29),
`complenantname` varchar(29),
`reportdate` varchar(29),
`report` varchar(75),
`crimecategory` varchar(29) ,
`chargedtocourt` varchar(29),
`Photo` BLOB(19),
PRIMARY KEY  (id)
)")
 or die(mysql_error());
 
 // Create a MySQL table in the selected database
mysql_query("CREATE TABLE foreigners_register(
`id` int(5) default NULL,
`Firstname` varchar(19) ,
`othernames` varchar(19),
`countryorigin` varchar(19),
`stateResident` varchar(29),
`LGAresident` varchar(29),
`residentialadress` varchar(29),
`permitNo` varchar(29) ,
`phot` blob,
PRIMARY KEY(id)
)")
 or die(mysql_error());
 
 mysql_query("CREATE TABLE wanted(
`crimeid` int(5) default NULL,
`Firstname` varchar(19) ,
`othernames` varchar(19),
`charges` varchar(29) ,
`phot` blob,
PRIMARY KEY(crimeid)
)")
 or die(mysql_error());
 
  mysql_query("CREATE TABLE graph(
`id` int(5) default NULL,
`category` varchar(19) ,
`count` int(19),
PRIMARY KEY(id)
)")
 or die(mysql_error());
 
 
 
 // Create a MySQL table in the selected database
mysql_query("CREATE TABLE admin(
`id` int(5) default NULL,
`username` varchar(45) NOT NULL,
`password` varchar(45) NOT NULL,
PRIMARY KEY  (password)
)")
 or die(mysql_error());
 
 
 
 // Create a MySQL table in the selected database
mysql_query("CREATE TABLE alert_tbl(
`id` int(5) default NULL,
`Reg_No` varchar(29) NOT NULL,
`pic` BLOB(19),
`comment` varchar(19),
PRIMARY KEY  (id)
)")
 or die(mysql_error());



   // put your code here 
				}
			} else {
				/* Check if the database that existed is in UTF-8, if not, ask for retry */
				$sql = "SHOW CREATE DATABASE $_POST[db_name]";
				$result = mysql_query($sql, $db);
				$row = mysql_fetch_assoc($result);
				
				if (!preg_match('/CHARACTER SET utf8/i', $row['Create Database'])){
					$errors[] = 'Database <b>'.$_POST['db_name'].'</b> is not in UTF8.  Please set the database character set to UTF8 before continuing by using the following query: ALTER DATABASE `'.$_POST['db_name'].'` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci.  To use ALTER DATABASE, you need the ALTER privilege on the database.';
				}
			}
		}

			
			
			
			}
		

	
?>
                  </div>  <form action="step2.php" method="post" name="form">
                    <p align="center">
                      <input type="hidden" name="action" value="process" />
                      <input type="hidden" name="step" value="2" />
                      <input type="hidden" name="new_version" value="<?php echo $_POST['new_version']; ?>" />
                      </p>
                <div align="center">
                  <table width="65%" border="1" align="center" cellpadding="1"  cellspacing="0" bgcolor="#FFFFFF" class="pp">
                    <tr><td class="row1"><div class="required" title="Required Field"></div><b><label for="db"><font color="white"><b>Database Hostname:</b></font></label></b><br />
                      Hostname of the database server. Default: <kbd>localhost</kbd></td>
                      <td class="row1" valign="middle"><input type="text" name="db_host" id="db" value="<?php if (!empty($_POST['db_host'])) { echo stripslashes(htmlspecialchars($_POST['db_host'])); } else { echo 'localhost'; } ?>" class="formfield" /></td>
                    </tr>
                    <tr><td class="row1"><div class="required" title="Required Field"></div><b><label for="port"><font color="white">Database Port:</font></label></b><br />
                      The port to the database server. Default: <kbd>3306</kbd></td>
                      <td class="row1"><input type="text" name="db_port" id="port" value="<?php if (!empty($_POST['db_port'])) { echo stripslashes(htmlspecialchars($_POST['db_port'])); } else { echo '3306'; } ?>" class="formfield" /></td>
                    </tr>
                    <tr><td class="row1"><div class="required" title="Required Field"></div><b><label for="username"><font color="white">Database Username:</font></label></b><br />
                      The username to the database server.</td>
                      <td class="row1"><input type="text" name="db_login" id="username" value="<?php echo stripslashes(htmlspecialchars($_POST['db_login'])); ?>" class="formfield" /></td>
                    </tr>
                    <tr><td class="row1"><div class="required" title="Required Field"></div><b><label for="pass"><font color="white">Database Password:</font></label></b><br />
                      The password to the database server.</td>
                      <td class="row1"><input type="text" name="db_password" id="pass" value="<?php echo stripslashes(htmlspecialchars($_POST['db_password'])); ?>" class="formfield" /></td>
                    </tr>
                    <tr><td class="row1"><div class="required" title="Required Field"></div><b><label for="name"><font color="white">Database Name:</font></label></b><br />
                      The name of the database to use. It will be created if it does not exist.<br /><kbd></kbd></td>
                      <td class="row1"><input type="text" name="db_name" id="name" value="<?php if (!empty($_POST['db_name'])) { echo stripslashes(htmlspecialchars($_POST['db_name'])); } else { echo 'crime'; } ?>" class="formfield" /></td>
                    </tr>
                    </table>
                </div>
	                                                                      
	   <?php

error_reporting(E_ALL ^ E_NOTICE);


if (isset($_POST['submit'])) {
	if ($_POST['submit'] == 'create') {
		unset($_POST['submit']);
		 
	} 
}


?>
                    <p align="center"><a href="step1.php" class="style14"></a>
                      <input type="submit" class="styled-button-10" value="create" name="submit" />
                      <a href="step3.php" class="style14">Next</a>
                      </div>
                    
                    
                  </form></td>
      <td width="15">&nbsp;</td>
      </tr>
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            <!--DWLayoutEmptyCell-->&nbsp;
      </table></td>
      </tr>
        
        
        

  

  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
   <!--DWLayoutEmptyCell-->&nbsp;
      </table></td>
    </tr>
    <tr>
      <td height="4"></td>
      <td></td>
    </tr>
  </table>
</div>
</body>
</html>
