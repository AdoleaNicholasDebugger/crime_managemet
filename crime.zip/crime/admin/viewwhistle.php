<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
<?php
include '../../config/dbconfig.php'
?>
<?php
//Connects to your Database
mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');
	?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>NACOSS e-Voting </title>
<link rel="stylesheet" href="style.css" type="text/css" />
<script language='JavaScript' type='text/JavaScript'>
<!--
function validate() {
	if(document.form1.query.value=='')
		{
		alert('input your Reg_No');
		return false;
		}
          else	{
		return true;
			}
}
//-->



</script>
<style type="text/css">
<!--
.style4 {color: #990000; font-weight: bold; }
.style5 {color: #FF0000}
-->
</style>
</head>
<body>
<div>
*********************************************
  <label><span class="style5">NACOSS e-Voting Whistle Report</span> </label>
</div>
 
<div id="body">

	<table width="80%" border="1">
	
    
    <tr>
	 <td><span class="style4">Reg.No</span></td>
    <td><span class="style4">comment</span></td>
    <td><span class="style4">evidence</span></td>
    </tr>
    <?php
	error_reporting(E_ALL ^ E_NOTICE);
	
	$sql="SELECT * FROM whistle";
	$result_set=mysql_query($sql);
	while($row=mysql_fetch_array($result_set))
	
	
	{
		?>
        <tr>
		<td><?php echo $row['Reg_No'] ?></td>
        <td><?php echo $row['comment'] ?></td>
        <td><a href="../../registration/images/<?php echo $row['picture'] ?>" target="_blank">view evidence </a></td>
        </tr>
        <?php
	}
	?>
    </table>
   
</div>
</body>
</html>