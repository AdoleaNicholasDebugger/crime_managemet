<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
<?php
include '../config/dbconfig.php'
?>


<?php
error_reporting(E_ALL ^ E_NOTICE);
	session_start();

$username = $_POST['username'];

$password = $_POST['password'];



if (isset( $username ) && isset($password)) {



    // Connect to MySQL


   

    // Select database on MySQL server

if(isset($_POST['password']))
{
     $_SESSION['password'] = $_POST['password'];
}

   


    // Formulate the query



   

  $sql = mysqli_query($db,"SELECT * FROM admin WHERE username = '".$username."' AND password = '".$password."'") or die(mysqli_error());
	

	
	





    // Execute the query and put results in $result



   

    // Get number of rows in $result.



    $num = mysqli_num_rows( $sql );







    if ( $num == 1 ) {





        $auth = true;







		$row=mysqli_fetch_row($sql);



			$usero=$row[3];

			$passo=$row[4];

			







		setcookie("user","");

		setcookie("pass","");

		setcookie("pass",$passo);

		setcookie("user",$usero);

		











    }



}



if ( ! $auth ) {

?>
		<script>
		alert('wrong User.Name/Password');
        window.location.href='../admin/login.html';
        </script>
		<?php



} else {





   header("Location:admindashboard.php");







}

?>
