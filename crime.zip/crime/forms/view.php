<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">
<?php
include '../config/dbconfig.php';
?>
<?php
//Connects to your Database
mysql_connect($dbhost,$dbuser,$dbpass) or die('cannot connect to the server'); 
mysql_select_db($dbname) or die('database selection problem');
	?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>NACOSS e-Voting </title>
<link rel="stylesheet" href="style.css" type="text/css" />
<script language='JavaScript' type='text/JavaScript'>
<!--
function validate() {
	if(document.form1.query.value=='')
		{
		alert('input your Reg_No');
		return false;
		}
          else	{
		return true;
			}
}
//-->



</script>
<style type="text/css">
<!--
.style1 {
	color: #FF9999;
	font-weight: bold;
}
.style4 {color: #990000; font-weight: bold; }
.style5 {color: #FF0000}
-->
</style>
</head>
<body>
<div id="header">
<label>NACOSS e-Voting </label>
</div>
<div>
*********************************************
</div>
 <form method="get" action="" name="form1" onSubmit='return validate();'>
    <label><font color="BLUE"><B>Search by:Reg.No*</font> </label><input type="text" name="query" />
<input type="submit" name="submit" value="Search" />
</form></td>
<div id="body">

	<table width="80%" border="1">
	
    <tr>
    <th colspan="5"><span class="style1">Voters Register</span>...<a href="../home/index.html">Home
        <label>...</label>
    </a>      <label></label></th>
    </tr>
    <tr>
	 <td><span class="style4">Reg.No</span></td>
	 <td><span class="style4">First Name</span></td>
    <td><span class="style4">Last Name</span></td>
    <td><span class="style4">Department</span></td>
    <td><span class="style4">Photo</span></td>
    </tr>
    <?php
	error_reporting(E_ALL ^ E_NOTICE);
	$query=$_POST["query"];

$query=mysql_real_escape_string($_GET['query']);

 
	$sql="SELECT * FROM registration WHERE

Reg_No like '%".$query."%'";
	$result_set=mysql_query($sql);
	while($row=mysql_fetch_array($result_set))
	
	
	{
		?>
        <tr>
		<td><?php echo $row['Reg_No'] ?></td>
        <td><?php echo $row['first_name'] ?></td>
        <td><?php echo $row['last_name'] ?></td>
        <td><?php echo $row['Department'] ?></td>
        <td><a href="FORMS/images/<?php echo $row['picture'] ?>" target="_blank">view picture </a></td>
        </tr>
        <?php
	}
	?>
    </table>
   
</div>
</body>
</html>