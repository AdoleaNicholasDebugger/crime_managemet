<html>
<head><title>Omolola</title>
<style type="text/css">
<!--
.roundtable {
border: 1px solid #cbcbcb;
color:#666;
vertical-align:top;
margin-right:15px;
-moz-border-radius:7px; -webkit-border-radius:7px; -khtml-border-radius:7px; border-radius:7px; behavior: url(border-radius.htc);
}
-->
</style>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /></head>
</html>

 <?php

/************************************************************************/
/* Haruna                                               */
/************************************************************************/
/* Copyright (c) 2013                                                  */
/************************************************************************/

?>

<style type="text/css">
<!--
.style2 {
	color: #660000;
	font-weight: bold;
}
.style1 {color: #000099}
-->
</style>



<style type="text/css">
.styled-button-12 {
	-webkit-box-shadow:rgba(0,0,0,0.98) 0 1px 0 0;
	-moz-box-shadow:rgba(0,0,0,0.98) 0 1px 0 0;
	box-shadow:rgba(0,0,0,0.98) 0 1px 0 0;
	background-color:#EEE;
	border-radius:0;
	-webkit-border-radius:0;
	-moz-border-radius:0;
	border:1px solid #999;
	color:#666;
	font-family:'Lucida Grande',Tahoma,Verdana,Arial,Sans-serif;
	font-size:11px;
	font-weight:700;
	padding:2px 6px;
	height:28px
}
.style11 {color: #660033}
.style12 {color: #660000}
.style13 {color: #333333}
</style>


<div align="center">
  <div align="center">
    <table width="1193" border="0" cellpadding="0" cellspacing="0" bgcolor="#CCCCCC">
      <!--DWLayoutTable-->
      <tr>
        <td width="58" height="20"></td>
        <td width="111"></td>
        <td width="250"></td>
        <td width="63">&nbsp;</td>
        <td width="31">&nbsp;</td>
        <td width="85">&nbsp;</td>
        <td width="68">&nbsp;</td>
        <td width="74">&nbsp;</td>
        <td width="38">&nbsp;</td>
        <td width="60">&nbsp;</td>
        <td width="220">&nbsp;</td>
        <td width="135"></td>
      </tr>
      <tr>
        <td height="59"></td>
        <td></td>
        <td></td>
        <td colspan="5" valign="top" bgcolor="#FF3300"><img src="logo.jpg" width="730" height="98" />&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td></td>
      </tr>
      
      <tr>
        <td height="49"></td>
        <td></td>
        <td></td>
        <td></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td></td>
      </tr>
      
      
      <tr>
        <td height="19"></td>
        <td></td>
        <td></td>
        <td></td>
        <td>&nbsp;</td>
        <td colspan="2" valign="top" bgcolor="#FFFFFF"><span class="style2">Installation module </span></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
      <tr>
        <td height="26"></td>
        <td></td>
        <td></td>
        <td></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
      </tr>
      
      <tr>
        <td height="19"></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td valign="top" bgcolor="#FFFFFF"><span class="style1">Stage 1/3</span></td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
        <td>&nbsp;</td>
      </tr>
      
      <tr>
        <td height="174"></td>
        <td></td>
        <td colspan="9" valign="top">
          
          <div align="center">
          <div align="center">
            <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#990033" class="roundtable">
              <!--DWLayoutTable-->
              <tr>
                <td width="872" height="74">&nbsp;</td>
              </tr>
              <tr>
                <td height="20" valign="top" bgcolor="#CCCCCC" class="style8 style11"> piracy is a penal offence! No part of this application should be distributed without the prior notice of the developer. </td>
              </tr>
              <tr>
                <td height="75">&nbsp;</td>
              </tr>
            </table>
          </div>
      <td>      </tr>
      <tr>
        <td height="17"></td>
        <td></td>
        <td>      
        <td>      
        <td>      
        <td>      
        <td>      
        <td>      
        <td>      
        <td>        
        <td>        
      <td>      </tr>
      <tr>
        <td height="3"></td>
        <td></td>
        <td>      
        <td>      
        <td>      
        <td>      
        <td>      
        <td>      
        <td>      
        <td rowspan="2" valign="top">      <strong><a href="step2.php">Next</a></strong>
        <td>      
        <td>            </tr>
      <tr>
        <td height="19"></td>
        <td></td>
        <td colspan="2" valign="top">      <span class="style12"><strong>(c)</strong> 2016</span>
        <td>      
        <td>      
        <td>      
        <td>      
        <td>      
        <td>      
        <td>            </tr>
      <tr>
        <td height="205"></td>
        <td></td>
        <td>      
        <td>      
        <td>      
        <td>      
        <td>      
        <td>      
        <td>      
        <td>      
        <td>      
      <td>      </tr>
      
      <tr><td height="18"></div>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <tr><td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>
      <td></td>      
      <td>&nbsp;</td>
  </table>
</div>
  </div>
