
<?php
include 'config/dbconfig.php';
?>
<?php

error_reporting(E_ALL ^ E_NOTICE);
 //This is the directory where images will be saved
 $target = "images/";
 $target = $target . basename( $_FILES['photo']['name']);

 //This gets all the other information from the form

$Reg_No=$_POST['Reg_No'];
$pic=($_FILES['photo']['name']);
$comment=$_POST['comment'];
 


if($_FILES['photo']['size']>500000)	
{
?>
		<script>
		alert('Image file too large, must be less than 500kb');
        window.location.href='whistle.php';
        </script>
		<?php
}
elseif($_FILES['photo']['size']<=0)
{
?>
		<script>	
		alert('Image file not loaded');
        window.location.href='whistle.php';
        </script>
		<?php
}
	else
	{
	 $sql = mysqli_query($db,"SELECT * from alert_tbl") or die(mysqli_error());
	

		$pin=1;
	
	
	while ($row = mysqli_fetch_array($sql)) {
$pin=$pin+1; 
}

$query="insert into alert_tbl
values('$pin','$Reg_No','$pic','$comment')";

$result=mysqli_query($db,$query);
//Writes the photo to the server
if($result){
 if(move_uploaded_file($_FILES['photo']['tmp_name'], $target))

?>
		<script>
		alert('successfully uploaded');
        window.location.href='index.html?success';
        </script>
		<?php
	}
	else
	{
		?>
		<script>
		alert('error while uploading file[HINT:you probably attempt to save multiple RegNo]');
        window.location.href='don.gif?fail';
        </script>
		<?php
	}
	}

 ?>