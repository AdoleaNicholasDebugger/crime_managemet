<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">

<?php

error_reporting(E_ALL ^ E_NOTICE);
 
$UserName=$_POST['UserName'];
$Password=$_POST['Password'];



//Connects to your Database

include '../config/dbconfig.php';

	
	$Password=($Password);
	
	$query="select * from admin ";
	$temp=1;
	$result=mysqli_query($db,$query);
	
	while ($row = mysqli_fetch_array($result)) {
$temp=$temp+1; 
}

$query="insert into admin
values('$temp','$UserName','$Password')";

$result=mysqli_query($db,$query);
//Writes the photo to the server
if($result){

?>
		<script>
		alert('account successfully created');
        window.location.href='../admin/admindashboard.php';
        </script>
		<?php
	}
	else
	{
		?>
		<script>
		alert('error while creating account');
        window.location.href='../admin/admindashboard.php';
        </script>
		<?php
	}
	

 ?>
