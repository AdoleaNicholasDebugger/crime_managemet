<div id="wrapper">
  <div id="header"> 
      <div id="slogan">
       <img src="../images/logo.jpg" width="980" height="158" align align="center" />
      
  </div>
<?php
include '../config/dbconfig.php';
?>
<?php

if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

$result = mysqli_query($db,"SELECT * FROM alert_tbl");

echo "<table border=1>
<tr>
<th>Reporter's Name</th>
<th>Report</th>
</tr>";

while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $row['Reg_No'] . "</td>";
echo "<td>" . $row['comment'] . "</td>";
echo "</tr>";
}
echo "</table>";

mysqli_close($db);
?>
