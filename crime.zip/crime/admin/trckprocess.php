<link rel="icon" type="image/png" sizes="16x16" href="favicon-16x16.png">

<?php
include '../config/dbconfig.php'
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>NACOSS e-Voting </title>
<link rel="stylesheet" href="style.css" type="text/css" />
<script language='JavaScript' type='text/JavaScript'>
<!--
function validate() {
	if(document.form1.query.value=='')
		{
		alert('input your Reg_No');
		return false;
		}
          else	{
		return true;
			}
}
//-->



</script>
<style type="text/css">
<!--
.style1 {
	color: #0000FF;
	font-weight: bold;
}
.btn {
	-webkit-box-shadow:rgba(0,0,0,0.2) 0 1px 0 0;
	-moz-box-shadow:rgba(0,0,0,0.2) 0 1px 0 0;
	box-shadow:rgba(0,0,0,0.2) 0 1px 0 0;
	border-bottom-color:#333;
	border:1px solid #61c4ea;
	background-color:#7cceee;
	border-radius:5px;
	-moz-border-radius:5px;
	-webkit-border-radius:5px;
	color:#333;
	font-family:'Verdana',Arial,sans-serif;
	font-size:14px;
	text-shadow:#b2e2f5 0 1px 0;
	padding:5px
}
.style4 {color: #990000; font-weight: bold; }
.style5 {color: #FF0000}
.style6 {color: #0000FF}
-->
</style>
</head>
<body>
<div id="header">
<label></label>
</div>
<div></div>
 
<div id="body">

	<table width="80%" border="1" >
	<tr><img src="logo.jpg"></tr>
	
    <tr>
    <th colspan="5"><span class="style1">Crime Tracking </span><span class="style6">...
     
    </span>
    </tr>
    <tr>
	
	 <td><span class="style4">Firstname</span></td>
    <td><span class="style4">Othernames</span></td>
    <td><span class="style4">State</span></td>
	<td><span class="style4">LGA</span></td>
	<td><span class="style4">Home_address</span></td>
    
    </tr>
    <?php
	
	error_reporting(E_ALL ^ E_NOTICE);
	$query=$_POST["query"];
	

$query=($_GET['query']);

 
	$sql="SELECT * from citizens_register WHERE First_name='$query'";
	$result_set=mysqli_query($db,$sql);
	
	while($row=mysqli_fetch_array($result_set))
	
	
	{
	$First_name = $row["First_name"]; 
	$Other_Names = $row["Other_Names"]; 
	$State = $row["State"]; 
	$LGA = $row["LGA"]; 
	$Home_address = $row["Home_address"]; 
	?>
        <tr>
		<td><?php echo $row['First_name'] ?></td>
        <td><?php echo $row['Other_Names'] ?></td>
        <td><?php echo $row['State'] ?></td>
		<td><?php echo $row['LGA'] ?></td>
        <td><?php echo $row['Home_address'] ?></td>
        </tr>
        <?php
	}
	?>
    </table>
   
</div>
</body>
</html>






